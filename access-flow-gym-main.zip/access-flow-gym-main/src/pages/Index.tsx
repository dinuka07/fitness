import { FitAccessDashboard } from "@/components/FitAccessDashboard";

const Index = () => {
  return <FitAccessDashboard />;
};

export default Index;
